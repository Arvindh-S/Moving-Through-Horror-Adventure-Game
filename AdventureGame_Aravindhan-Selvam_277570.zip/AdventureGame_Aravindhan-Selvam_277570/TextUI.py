def part1():
    import time #the time function makes delays in the text output to make the game more interactive and dramatic
    print("""Hello, and welcome to the ADVENTURE GAME!
        Let's dive into the world of horror and mystery! ☆-🎬-☆

        During Friday the 13th, Lance wakes up in the middle of the night because he hears a banging sound in the 
        hallway. 
        He is scared because the sound is getting closer and louder. He could now either stay in the room or open the 
        door and see what was making the noise.

        What do you want to do: Stay or Explore? """)

    c1 = input() #Prompts the users the input their choice
    time.sleep(2)
    answer = 'incorrect'
    while answer == 'incorrect':
        if c1.upper() == "STAY":
            print(
                "\nLance decides to stay in the room, and since no one comes to help him, he stays there forever.")
            answer = 'correct'
        elif c1.upper() == "EXPLORE":
            print("\nLance exits the room silently and starts investigating the reason behind the sound.")
            answer = 'correct'
            part2()
        else:
            print("ENTER THE CORRECT CHOICE! STAY or EXPLORE?")
            c1 = input()

def part2():
    import time
    print("""\n\nLance starts walking down the hallway, and the sound is getting louder and louder.
    He discovers a strange and horrifying type of doll in the main hall lying on the floor, with bloodstains 
    all over the doll's clothing. 
    He wanted to pick the doll, but his hands are trembling in fear as he does so. Should he, though? It does 
    not belong to him and appears to be horrifying.

    Enter your choice: Pick or Ignore?""")
    time.sleep(2)
    c1 = input()
    ans = 'incorrect'
    while ans == 'incorrect':
        if c1.upper() == "PICK":
            print(
                """\nThe second Lance took the hideous doll in his hands, the doll began to talk! Lance heard the doll 
            whisper that she was cursed, that this house belonged to her, and that she would not allow him to live 
            here anymore. Lance then threw the doll away and went back to his room to sleep.
            When he was sleeping, he had a nightmare again, and the doll began to capture his body and tie him up 
            to the wall. Lance, in his dream, made an attempt to flee by running to his room, but it's too late!
            He is still unconscious and is still in his dream. Now, the doll grabbed him and said that she would 
            not allow him to survive or leave this house.!""")
            time.sleep(2)
            ans = 'Correct'
            pick = "True"
        elif c1.upper() == 'IGNORE':
            print("""\nLance decides to not pick up the doll and walked again to his room and slept the whole night.""")
            ans = 'Correct'
            pick = "False"
        else:
            print("Wrong Input! Enter PICK or IGNORE?")
            c1 = input()
            time.sleep(2)
            print(
                """\nThe next morning he wakes up from the nightmare and when he went downstairs the doll was seen 
            lying in the Sofa on the hall. 
            Lance then begins to rush to the nearby church for help and to save his life""")
    time.sleep(2)
    part3(pick)

def part3(pick_value):
    import time
    print("""\n\nAfter a while, when Lance was taking a walk he saw the real MONSTER inside of the doll lying on the
    floor and the clothes of the doll was in full of blood stain.
    The doll had a red eyes and evil looks. He got very scared and ran towards his room!""")
    time.sleep(2)
    if pick_value == "True":
        time.sleep(2)
        print("""But then he remembered! He had the holy book provided by padre of the church and he started reading it 
        infront of the monster!
        Well he had nothing to lose and can't do anything else!""")
        time.sleep(2)
        print("\n The monster SCREAMED in pain but tries to attack him but the monster not able to tolerate the pain!")
    elif pick_value == "False":
        print("The monster escaped and told to Lance that she will again come tomorrow and will not leave him !")

def part4():
    import time
    from Backpack import Backpack
    backpack = Backpack()
    print("""\n\nIn the next morning, while exploring the house, Lance discovers a mysterious door that seems to lead 
    to the basement.
    The door is old and creaky, and Lance feels a strange energy emanating from it. What will Lance do now?

    Enter your choice: Open or Ignore?""")
    time.sleep(2)
    c1 = input()
    ans = 'incorrect'
    while ans == 'incorrect':
        if c1.upper() == "OPEN":
            print(
                """\nLance bravely opens the door, revealing a dark and creepy staircase leading down to the basement. 
            As he descends, he hears eerie sounds and feels a chilling breeze.
            At the bottom, he finds an ancient chest. Inside the chest, he discovers a magical amulet that seems to 
            have protective powers!""")
            print("You have a backpack to store items.")
            backpack.add_item('magical amulet')
            print(f"{'magical amulet'} added to the backpack.")

            print("""\nFeeling more confident with the magical amulet, Lance decides to continue exploring the basement. 
            As he ventures deeper, he encounters strange symbols on the walls and a hidden passage.
            What will Lance do next?

            Enter your choice: Investigate or Go back?""")
            c2 = input()
            while c2.upper() not in ["INVESTIGATE", "GO BACK"]:
                print("Wrong Input! Enter INVESTIGATE or GO BACK?")
                c2 = input()
            if c2.upper() == "INVESTIGATE":
                print("""\nLance examines the symbols closely and realizes they are ancient runes. Suddenly, a mystical 
                portal opens, revealing a secret chamber with untold treasures!
                Lance collects the treasures and decides to return to his room to plan his next move.""")
                part5(backpack)  # Call part5() after part4() completes
            elif c2.upper() == "GO BACK":
                print("\nLance decides to go back upstairs, leaving the mysterious symbols behind for now.")
            ans = 'correct'
        elif c1.upper() == 'IGNORE':
            print("""\nLance chooses to ignore the mysterious door and continues exploring other parts of the house.""")
            ans = 'correct'
        else:
            print("Wrong Input! Enter OPEN or IGNORE?")
            c1 = input()
            time.sleep(2)

def part5(backpack):
    import time

    print("""\n\nIn the attic, Lance discovers an ancient book with a lock on it. The book seems to radiate mystical energy.
    Lance remembers the magical amulet in his backpack. What will he do?

    Enter your choice: Use amulet or Ignore?""")
    
    c1 = input()
    ans = 'incorrect'
    while ans == 'incorrect':
        if c1.upper() == "USE AMULET":
            if backpack.has_item("magical amulet"):
                print("""\nLance uses the magical amulet to unlock the ancient book. As he opens the book, a burst of magical energy
                surrounds him. The book contains powerful spells and information about the curse haunting the house.""")
                print("\nCongratulations! Lance has successfully broken the curse and saved himself from the haunted house.")
            else:
                print("\nYou don't have the magical amulet to unlock the book. Explore the basement to find it.")
            ans = 'correct'
        elif c1.upper() == 'IGNORE':
            print("""\nLance decides to ignore the ancient book for now and continues exploring the attic.""")
            ans = 'correct'
        else:
            print("Wrong Input! Enter USE AMULET or IGNORE?")
            c1 = input()