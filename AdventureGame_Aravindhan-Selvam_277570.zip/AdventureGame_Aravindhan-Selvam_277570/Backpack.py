class Backpack:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def remove_item(self, item):
        self.items.remove(item)

    def check_items(self):
        for item in self.items:
            print(item)

    def has_item(self, item_name):
        return item_name in self.items