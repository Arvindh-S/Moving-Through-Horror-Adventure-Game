import TextUI as text

def game():
    text.part1()
    print("\n\n")
    print("=================================END OF CHAPTER 1=================================")
    while True:
        try:
            text.part4()
            break  # Break out of the loop if part4() completes without errors
        except ValueError:
            print("Invalid input. Please enter a valid choice.")
    print("\n\n")
    print("=================================END OF CHAPTER 2=================================")